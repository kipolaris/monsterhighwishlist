package com.monsterhighwishlist.Data

enum class WishlistCategory {
    WISHLIST,
    CONSIDERING,
    ALREADY_SECURED
}